# Inertia.js Laravel Adapter

<p align="left">
  <a href="https://github.com/inertiajs/inertia-laravel/releases">
    <img src="https://img.shields.io/github/release/inertiajs/inertia-laravel.svg?style=flat-square" alt="Latest Version">
  </a>
  <a href="https://github.com/inertiajs/inertia-laravel/actions/workflows/tests.yml?query=workflow%3Atests+branch%3Amaster">
    <img src="https://github.com/inertiajs/inertia-laravel/actions/workflows/tests.yml/badge.svg?branch=master" alt="Build Status">
  </a>
  <a href="https://styleci.io/repos/174395905">
    <img src="https://styleci.io/repos/174395905/shield" alt="StyleCI">
  </a>
  <a href="https://packagist.org/packages/inertiajs/inertia-laravel">
    <img src="https://img.shields.io/packagist/dt/inertiajs/inertia-laravel.svg?style=flat-square" alt="Total Downloads">
  </a>
</p>

---

Visit [inertiajs.com](https://inertiajs.com/) to learn more.
